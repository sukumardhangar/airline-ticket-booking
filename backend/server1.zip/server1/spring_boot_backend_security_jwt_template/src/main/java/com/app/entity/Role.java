package com.app.entity;


public enum Role {
 CUSTOMER,OPERATOR,ADMIN
}
