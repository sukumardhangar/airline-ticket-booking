package com.app.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SeatValueList {
	private Long seatingNumber;
	private Long passangerId;
}
