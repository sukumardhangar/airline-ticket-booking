package com.app.entity;

public enum StatusType {
PENDING,DONE,REJECTED
}
