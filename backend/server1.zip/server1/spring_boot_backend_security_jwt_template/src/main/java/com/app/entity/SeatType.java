package com.app.entity;

public enum SeatType {
	BUSSINESS,ECONOMY
}
