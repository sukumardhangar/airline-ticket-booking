package com.app.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SeatSendDetailDto {
	  private Long seatTypeNumber;
	   private Long seatingNumber;
	   private Long PassangerId;

}
